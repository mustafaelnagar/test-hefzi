using System;

class Dog : Animal
{
    public override void Eat()
    {
        Console.WriteLine("Äter");
    }
}
