using System;

interface IVehicle
{
    void Drive();
    bool Refuel(int amount);
}
